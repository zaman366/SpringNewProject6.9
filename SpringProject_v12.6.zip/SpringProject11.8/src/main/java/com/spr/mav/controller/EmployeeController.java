
package com.spr.mav.controller;

import com.spr.mav.controller.impl.IEmployeeController;
import com.spr.mav.dao.impl.IEmployeeDAO;
import com.spr.mav.model.Employee;
import com.spr.mav.service.impl.IEmployeeService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController

public class EmployeeController implements IEmployeeController {
     @Autowired
      IEmployeeService employeeService;
     
      @Autowired
       IEmployeeDAO employeeDAO;

    @Override
    public String getAllEmployees() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ModelAndView create() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    
    
    
    
    @Override
     @RequestMapping(value ="/save", method = RequestMethod.POST)
      public ModelAndView save(HttpServletRequest request) {
      employeeService.save(request);
      System.out.println("hello");
      return new ModelAndView("/admin/employeeData");
    }
    
    
    
    
    
    
    

    @Override
    public ModelAndView edit(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
//    @RequestMapping(value ="/empUpdate", method = RequestMethod.POST)
    public ModelAndView update(HttpServletRequest request) {
//        employeeService.update(request);
        return  new ModelAndView("");
    }

    
    
    
    
    @Override
    public ModelAndView delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Employee> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
//    New Generated Method
    
    
     @RequestMapping(value ="/empVi")
    public ModelAndView viewEmp() {
      List<Employee> emps = employeeService.getAll();
      
       Map<String,Object> map=new HashMap<String,Object>();
       map.put("employees",emps);
        
      return new ModelAndView("/admin/empView1","map",map);
        
 }
    
    
  
    
    
    
    
    
    
    //new
    
       @RequestMapping(value ="/empVi2")
    public ModelAndView view() {
      List<Employee> emps = employeeService.getAll();
      
       Map<String,Object> map=new HashMap<String,Object>();
       map.put("employees",emps);
        
      return new ModelAndView("/admin/salaryDataInsert","map",map);
        
 }
    
    
    
    
    
    
    
    
    
    //////empAction///
    
    
       @RequestMapping(value ="/empAction")
    public ModelAndView empAction() {
      List<Employee> emps = employeeService.getAll();
      
       Map<String,Object> map=new HashMap<String,Object>();
       map.put("employees",emps);
        
      return new ModelAndView("/admin/employeeDataUpdate1","map",map);
        
       
        
 }
    
    
    
    ////select/////
    
    @RequestMapping(value = "/select/{id}", method = RequestMethod.GET)
    public ModelAndView select(ModelMap map, @PathVariable("id") int id) {
        Employee em = employeeService.getById(id);
        map.addAttribute("em",em);
        return  new ModelAndView("/admin/employeeDataUpdate1");
    }
    
    
    
    @RequestMapping(value = "/selectToSalary/{id}", method = RequestMethod.GET)
    public ModelAndView selectS(ModelMap map, @PathVariable("id") int id) {
        Employee em = employeeService.getById(id);
        map.addAttribute("em",em);
        return  new ModelAndView("/admin/salaryDataInsert");
    }
    
    
    
    ////delete/////
    
    
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    public ModelAndView eDelete(@PathVariable("id") int id) { 
        employeeService.delete(id);
         return  new ModelAndView("/admin/employeeDataUpdate1");
    }
    
    
    
    ////update/////
    
    @RequestMapping(value ="/empUpdate", method = RequestMethod.POST)
    public ModelAndView eupdate(HttpServletRequest request) {
        employeeService.update(request);
        System.out.println("Employee Id: "+request.getParameter("empId"));
        
        
        
        
        
        
        
        return  new ModelAndView("/admin/employeeDataUpdate1");
    }
    
    
    
    
          ///////To Show Data from Leave Table//////
//    
//     @RequestMapping(value ="/showGroupWiseData")
//    public ModelAndView employeeGroupData(@RequestParam("empDep") String empDep) {
//      List<Employee> leaveData = leaveService.getLeaveHistory(empId);
//      
////      for(Leave leaveHi:leaveData){
////          System.out.println(leaveHi.getReqDays());
////           System.out.println(leaveHi.getActionStatus()); 
////           System.out.println(leaveHi.getLevReason());
////            System.out.println(leaveHi.getLevType());
////             System.out.println(leaveHi.getSubDate());
////           
////          
////      }
//      
//      //     return new ModelAndView("/admin/empleave");
//      
//       Map<String,Object> map= new HashMap<String,Object>();
//       map.put("leaveData",leaveData);
//        
//      return new ModelAndView("/admin/leaveHistoryTable","map",map);
//
// }
    
    
    
    
    
    
    /////////////employee data for attendence///////////
     @RequestMapping("/attendanceData")
    public ModelAndView empData(){
        
         List<Employee> emps = employeeService.getAll();
      
       Map<String,Object> map=new HashMap<String,Object>();
       map.put("emps",emps);
       
        
        return new ModelAndView("/admin/attendanceData","map",map);
    }
    
    
//    ///////////////////////employee data show/////////
//    
//    @RequestMapping("/attendanceDataTab")
//    public ModelAndView empDataShow(){
//        
//        List<Employee> emps = employeeService.getAll();
//      
//       Map<String,Object> map=new HashMap<String,Object>();
//       map.put("employees",emps);
//       
//        
//        return new ModelAndView("/admin/attendanceDataTab","map",map);
//    }
    
    
   
    
    
    
}
