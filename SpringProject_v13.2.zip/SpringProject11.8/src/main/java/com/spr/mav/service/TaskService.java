/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spr.mav.service;

import com.spr.mav.dao.impl.ITaskDAO;
import com.spr.mav.model.Task;
import com.spr.mav.service.impl.ITaskService;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author zaman
 */

@Service(value = "taskService")
public class TaskService implements ITaskService{
    
    
    @Autowired
    ITaskDAO taskDAO;

    ///////SaveToTaskTable///////
    @Override
    public Task save(HttpServletRequest request) {
        int id=Integer.parseInt(request.getParameter("id"));
         
        int empId=Integer.parseInt(request.getParameter("empId"));
        String empName=request.getParameter("empName");
        String empDep=request.getParameter("empDep");
        String empDeg=request.getParameter("empDeg");
        
        
        String taskId=request.getParameter("taskId");
        String taskName=request.getParameter("taskName");
        String description=request.getParameter("description");
        
        String startDate=request.getParameter("startDate");
        String status=request.getParameter("status");
        String note=request.getParameter("note");
        
        
        Task taskSave=new Task();
        
        taskSave.setId(id);
        
        taskSave.setEmpId(empId);
        
        taskSave.setEmpName(empName);
        
        taskSave.setEmpDep(empDep);
        
        taskSave.setEmpDeg(empDeg);
        
        taskSave.setTaskId(taskId);
        
        taskSave.setTaskName(taskName);
        
        taskSave.setDescription(description);
        
        taskSave.setStartDate(startDate);
        
        taskSave.setStatus(status);
        
        taskSave.setNote(note);
        
        return taskDAO.save(taskSave);
        
        
        
        
        
        
    }

    @Override
    public Task update(HttpServletRequest request) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Task delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Task> getAll() {
        List<Task> tasklist=taskDAO.getAll();
       return tasklist;
    }

    @Override
    public Task getById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
