
package com.spr.mav.service.impl;

import com.spr.mav.common.ICommonService;
import com.spr.mav.model.Employee;




public interface IEmployeeService extends ICommonService<Employee>{
    
}
