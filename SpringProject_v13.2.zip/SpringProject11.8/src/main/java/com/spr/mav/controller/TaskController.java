
package com.spr.mav.controller;

import com.spr.mav.controller.impl.ITaskController;
import com.spr.mav.model.Task;
import com.spr.mav.service.impl.ITaskService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;




@RestController
public class TaskController implements ITaskController{
    
    
    @Autowired
    ITaskService taskService;

    @Override
    public ModelAndView create() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /////////Save To Task Table//////////
    @Override
    @RequestMapping(value = "/saveTask",method = RequestMethod.POST)
    public ModelAndView save(HttpServletRequest request) {
        taskService.save(request);
       return new ModelAndView("/admin/assignTaskPage");
    }

    
    @Override
    public ModelAndView edit(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ModelAndView update(HttpServletRequest request) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ModelAndView delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Task> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    @RequestMapping(value ="/showTaskTable")
    public ModelAndView viewTaskTable() {
      List<Task> taskData = taskService.getAll();
      
       Map<String,Object> map=new HashMap<String,Object>();
       map.put("allTaskData",taskData);
        
      return new ModelAndView("/admin/taskAssignTable","map",map);
        
 }
    
    
    
}
